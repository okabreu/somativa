from rest_framework import serializers
from .models import*

# class ClienteSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Cliente
#         fields = '__all__'
#         many = True


# class FuncionarioSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Funcionario
#         fields = '__all__'
#         many = True

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id','username','email','is_superuser','first_name','last_login')
        many = True


class AutomovelSerializer(serializers.ModelSerializer):
    class Meta:
        model = Automovel
        fields = '__all__'
        many = True


class ProdutosSerializer(serializers.ModelSerializer):
    class Meta:
        model = Produtos
        fields = '__all__'
        many = True


class ManutencaoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Manutencao
        fields = '__all__'
        many = True


class PagamentoServicoSerializer(serializers.ModelSerializer):
    class Meta:
        model = PagamentoServico
        fields = '__all__'
        many = True


class RegistroServicoSerializer(serializers.ModelSerializer):
    class Meta:
        model = RegistroServico
        fields = '__all__'
        many = True


class PostoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Posto
        fields = '__all__'
        many = True


class ReservaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Reserva
        fields = '__all__'
        many = True