from django.shortcuts import render
from .models import *
from .serializers import *
from rest_framework.viewsets import ModelViewSet
from rest_framework.views import APIView
from rest_framework.response import Response
from datetime import datetime, timedelta
from rest_framework import filters
from django_filters.rest_framework import DjangoFilterBackend
#from .customFilters import *  
from django.db.models import Avg

from rest_framework.permissions import DjangoModelPermissionsOrAnonReadOnly, IsAuthenticated

# Create your views here.
