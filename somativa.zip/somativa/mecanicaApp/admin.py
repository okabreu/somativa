from django.contrib import admin
from .models import*

# Register your models here.
class detCliente(admin.ModelAdmin):
    list_display = ('id', 'Nome', 'CPF')
    list_display_links = ('id', 'Nome')
    search_fields = ('Nome', 'CPF')
    list_per_page = 10
    
admin.site.register(Cliente, detCliente)


class detFuncionario(admin.ModelAdmin):
    list_display = ('id', 'Nome', 'CPF')
    list_display_links = ('id', 'Nome')
    search_fields = ('Nome', 'CPF')
    list_per_page = 10
    
admin.site.register(Funcionario, detFuncionario)


class detAutomovel(admin.ModelAdmin):
    list_display = ('id', 'Categoria','Modelo')
    list_display_links = ('id','Categoria')
    search_fields = ('Categoria', 'Placa')
    list_per_page = 10
    
admin.site.register(Automovel, detAutomovel)


class detProdutos(admin.ModelAdmin):
    list_display = ('id', 'Nome','Fabricante')
    list_display_links = ('id','Nome')
    search_fields = ('id','Nome','Codigo')
    list_per_page = 10
    
admin.site.register(Produtos, detProdutos)


class detManutencao(admin.ModelAdmin):
    list_display = ('id', 'Nome','Categoria')
    list_display_links = ('id','Nome')
    search_fields = ('id','Nome','Categoria')
    list_per_page = 10
    
admin.site.register(Manutencao, detManutencao)


class detRegistroServico(admin.ModelAdmin):
    list_display = ('id', 'Nome','Categoria')
    list_display_links = ('id','Nome')
    search_fields = ('id','Nome','Categoria')
    list_per_page = 10
    
admin.site.register(RegistroServico, detRegistroServico)



 