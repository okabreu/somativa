from django.contrib import admin
from .models import*

# Register your models here.
class detCiente(admin.ModelAdmin):
    list_display = ('id', 'nome', 'CPF')
    list_display_links = ('id', 'nome')
    search_fields = ('nome', 'CPF')
    list_per_page = 10