from django.db import models
from django.utils import timezone
from django.db.models.signals import post_save
from django.core.validators import MinValueValidator, MaxValueValidator

# Create your models here.
class Cliente(models.Model):
    Nome = models.CharField(max_length=150, null = False, blank=False)
    Telefone = models.IntegerField()
    CPF = models.IntegerField()
    Endereco = models.CharField(max_length=150, null=False, blank=False)

    def __str__(self):
        return self.Nome

class Funcionario(models.Model):
    Nome = models.CharField(max_length=150, null = False, blank=False)
    CPF = models.IntegerField()
    Endereco = models.CharField(max_length=150, null=False, blank=False)
    Telefone = models.IntegerField()
    Email = models.CharField(max_length=150, null=False)
    
    def __str__(self):
        return self.Nome
    
class Automovel(models.Model):
    CATEGORIA = [
        ("Moto", "Moto"),
        ("Carro", "Carro"),
        ("Caminhão", "Caminhão"),
        ("Ônibus", "Ônibus")
    ]

    Categoria = models.CharField(max_length=150, choices=CATEGORIA)
    Marca = models.CharField(max_length=150, null = False, blank=False)
    Modelo = models.CharField(max_length=150, null = False, blank=False)
    Ano = models.IntegerField()
    Placa = models.IntegerField()

    def __str__(self):
        return self.Categoria
    
class Produtos(models.Model):
    Nome = models.CharField(max_length=150, null = False, blank=False)
    Fabricante = models.CharField(max_length=150, null = False, blank=False)
    Codigo = models.IntegerField()
    qtdEstoque = models.DecimalField(max_digits=10, decimal_places=2)
    valorCompra = models.DecimalField(max_digits=10, decimal_places=2)
    valorVenda = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return self.Nome

class Manutencao(models.Model):
    Nome = models.CharField(max_length=150, null = False, blank=False)
    Categoria = models.CharField(max_length=150, null = False, blank=False)
    valor = models.DecimalField(max_digits=10, decimal_places=2)
    produtoFK = models.ForeignKey(Produtos, related_name="produtos", on_delete=models.CASCADE, null=False, blank=True)

    def __str__(self):
        return self.Nome
    
class RegistroServico(models.Model):
    Nome = models.CharField(max_length=150, null = False, blank=False)
    ManutencaoFK = models.ForeignKey(Manutencao, related_name="manutencao", on_delete=models.CASCADE, null=False, blank=True)
    FuncionarioFK = models.ForeignKey(Funcionario, related_name="funcionario", on_delete=models.CASCADE, null=False, blank=True)
    AutomovelFK = models.ForeignKey(Automovel, related_name="automovel", on_delete=models.CASCADE, null=False, blank=True)
    ClienteFK = models.ForeignKey(Cliente, related_name="cliente", on_delete=models.CASCADE, null=False, blank=True)
    dataInicio = models.DateTimeField(default=timezone.now())
    dataEntrega = models.DateTimeField(default=timezone.now())

    def __str__(self):
        return self.Nome

class Posto(models.Model):
    POSTO = [
        ("A", "A"),
        ("B", "B"),
        ("C", "C")
    ]

    Posto = models.CharField(max_length=150, choices=POSTO)

    def __str__(self):
        return self.Posto

class Reserva(models.Model):
    Nome = models.CharField(max_length=150, null = False, blank=False)
    postoFK = models.ForeignKey(Posto, related_name="posto", on_delete=models.CASCADE, null=False, blank=True)
    data = models.DateTimeField(default=timezone.now())
    
    def __str__(self):
        return self.Nome
    